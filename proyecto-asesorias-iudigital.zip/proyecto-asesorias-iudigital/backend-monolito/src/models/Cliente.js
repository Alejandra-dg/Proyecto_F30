/**
 * Modelo Mongoose: Cliente
 * Representa al estudiante o entidad solicitante de la asesoría académica.
 */
const { Schema, model } = require('mongoose');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const clienteSchema = new Schema(
  {
    nombre: {
      type: String,
      required: [true, 'El nombre del cliente es obligatorio.'],
      trim: true,
      minlength: [3, 'El nombre del cliente debe tener al menos 3 caracteres.'],
    },
    email: {
      type: String,
      required: [true, 'El correo electrónico del cliente es obligatorio.'],
      trim: true,
      lowercase: true,
      unique: true,
      match: [EMAIL_REGEX, 'El formato del correo electrónico no es válido.'],
    },
  },
  {
    timestamps: {
      createdAt: 'fechaCreacion',
      updatedAt: 'fechaActualizacion',
    },
    versionKey: false,
  }
);

module.exports = model('Cliente', clienteSchema);
